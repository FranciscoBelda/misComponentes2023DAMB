export interface Componente {
  nombre: string;
  ruta: string;
  icono: string;
}
